classdef grid2DHU < grid2D 
% grid2DHU: (classdef) put into grid 2D, i.e., here for compatibility 
methods(Access=public) 

end % methods
end % classdef 