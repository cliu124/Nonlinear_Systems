% p2pversion
% : print pde2path version/date 
fprintf(['Running pde2path version 3.0 (June 2021) from ' pphome '\n']); 