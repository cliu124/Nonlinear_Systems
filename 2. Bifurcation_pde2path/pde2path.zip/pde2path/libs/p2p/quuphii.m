function quupi=quuphii(p,u,r) 
% quuphir: derivative of qu*phii, usually zero (for constraint q linear in u) 
quupi=sparse(p.nc.nq,p.nu); 