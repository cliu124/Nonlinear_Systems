function r=sG(p,u)
% sG: dummy sG, set in stanparam
fprintf('dummy sG from lib/p2p\n'); r=0; 