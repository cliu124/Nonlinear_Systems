function fig(nr)
% fig: shorthand for figure
figure(nr); 