function userplot(p,wnr) 
% userplot: Xcont version, called for p.plot.pstyle=-1; 
pplot(p,wnr); % p.u, and the current 'base mfd X' 
