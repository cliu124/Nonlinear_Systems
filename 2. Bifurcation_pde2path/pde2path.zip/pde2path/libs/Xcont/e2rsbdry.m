function ids=e2rsbdry(p,sig)
% e2rsbdry: select (only) boundary triangles for refinement
ids=bdtriangles(p.tri); 