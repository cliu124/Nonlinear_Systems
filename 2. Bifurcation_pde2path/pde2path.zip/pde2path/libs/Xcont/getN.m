function N=getN(p,X) 
% getN: unit normals, 
% if needed, change in problem dir to N=-per_vertex_normals(X,p.tri) 
N=per_vertex_normals(X,p.tri); 