function tis=mytitle(p)
% mytitle: dummy, template for user 'mytitle' to be used in pplot.m 
%
tis=[p.file.pname mat2str(p.file.count)]; 