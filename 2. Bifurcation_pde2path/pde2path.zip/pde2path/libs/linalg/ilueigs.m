function x=ilueigs(A,b,p) 
% ilueigs: AMGsolver for eigs-version  
x=lssAMG(A,b,p); 