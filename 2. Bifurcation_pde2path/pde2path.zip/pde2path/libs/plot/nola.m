xlabel(''); ylabel(''); 
% nola: convenience (script) to switch off labels