xticks([]); yticks([]); 
% noticks: convenience (script) to switch off ticks 