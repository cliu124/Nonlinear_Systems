xlabel(''); ylabel(''); 
% nolab: convenience (script) to switch off labels 