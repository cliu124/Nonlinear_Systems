xlabel(''); xticks([]); 
% noltix: convenience (script) to switch off labels