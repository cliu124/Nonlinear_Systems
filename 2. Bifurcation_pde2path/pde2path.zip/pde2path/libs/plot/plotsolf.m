function plotsolf(dir,sfname,wnr,cnr,pstyle)
% plotsolf: legacy interface to plotsol 
%  plotsolf(p,varargin) 
plotsol(dir,sfname,wnr,cnr,pstyle); 

