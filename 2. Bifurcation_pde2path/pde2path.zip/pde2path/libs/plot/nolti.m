xlabel(''); ylabel(''); xticks([]); yticks([]); 
% nolti: convenience (script) to switch off labels and ticks 