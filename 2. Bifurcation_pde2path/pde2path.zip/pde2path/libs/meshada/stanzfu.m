function z=stanzfu(p)
% stanzfu: choose z=u for trullekrul 
np=p.np; u=p.u(1:np); z=u; 
