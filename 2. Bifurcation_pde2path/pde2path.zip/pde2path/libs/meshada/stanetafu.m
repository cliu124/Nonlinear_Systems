function eta=stanetafu(p,np)
% stanetafu: choose trullekrul parameter eta=etafac*p.np 
eta=p.trop.etafac*np; 