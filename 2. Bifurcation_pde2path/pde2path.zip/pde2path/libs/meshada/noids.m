function obj=noids(obj)
% noids: dummy function for setting ids of bd-segments (oomeshada), 
% here: do nothing. Useful if same BCs on all boundary segments
end      