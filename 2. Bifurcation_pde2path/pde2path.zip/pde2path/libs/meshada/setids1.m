function obj=setids1(obj)
% setids1: set all boundary IDs to 1 (fallback) 
obj.e(5,:)=1; 