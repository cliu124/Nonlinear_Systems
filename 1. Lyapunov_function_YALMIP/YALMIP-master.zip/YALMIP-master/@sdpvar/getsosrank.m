function r=getsosrank(X)

try
    r = X.extra.rank;
catch
    r = inf;
end
  
  
      