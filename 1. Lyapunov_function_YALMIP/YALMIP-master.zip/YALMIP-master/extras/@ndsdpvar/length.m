function v = length(X)
% length (overloaded)

v = max(X.dim);