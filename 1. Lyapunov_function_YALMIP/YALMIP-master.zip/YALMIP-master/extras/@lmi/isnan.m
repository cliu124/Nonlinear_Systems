function YESNO = isnan(F)
YESNO=0;